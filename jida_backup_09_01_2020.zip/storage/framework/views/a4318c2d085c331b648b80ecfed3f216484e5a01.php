<html>
<head>
<title>Forward Condidate</title>
<style type="text/css">
	table{
		border-color:blue;
	}
</style>
</head>
<body>
    <?php if($data!=""): ?>
    <p><?php echo $data['saveContact']['Message'];"<br>" ?> </br></p>
    <table border="1px" style="border-collapse: collapse;">
        <tr><th colspan="2">Visiter Details</th></tr>
        <tr><th>Name:-</th><th><?php echo e(@$data['saveContact']['name']); ?></th></tr>
        <tr><th>Email:-</th><th><?php echo e(@$data['saveContact']['Email']); ?></th></tr>
        <tr><th>Phone:-</th><th><?php echo e(@$data['saveContact']['Phone']); ?></th></tr>
    </table>
    <?php endif; ?>
</body>
</html><?php /**PATH /home/baba/public_html/jiada/resources/views/emails/contact_mail.blade.php ENDPATH**/ ?>