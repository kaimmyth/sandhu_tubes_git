<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompanyType extends Model
{
    protected $primaryKey = 'id';
	public  $table = "company_types";
}
