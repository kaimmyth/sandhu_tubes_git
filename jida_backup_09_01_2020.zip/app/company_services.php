<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class company_services extends Model
{
    public $timestamps = false;
	public  $table = "company_services";
}
