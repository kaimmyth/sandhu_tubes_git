<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class module extends Model
{
    public $timestamps = false;
	protected $table = 'module';
}
