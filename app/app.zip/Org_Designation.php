<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Org_Designation extends Model
{
    protected $primaryKey = 'org_designation_id';
	public  $table = "org_designation";
}
