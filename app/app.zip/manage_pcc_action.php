<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class manage_pcc_action extends Model
{
    public $timestamps = false;
	public  $table = "manage_pcc_action";
}
