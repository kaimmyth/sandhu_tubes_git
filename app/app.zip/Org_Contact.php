<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Org_Contact extends Model
{
    protected $primaryKey = 'org_contact_type_id';
	public  $table = "org_contact_type";
}
