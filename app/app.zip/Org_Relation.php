<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Org_Relation extends Model
{
    protected $primaryKey = 'org_relation_id';
	public  $table = "org_relation";
}
