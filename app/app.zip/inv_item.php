<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class inv_item extends Model
{
	public $timestamps = false;
	public  $table = "inv_item";
}