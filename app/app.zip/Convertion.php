<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Convertion extends Model
{
    
    protected $primaryKey = 'convertions_id';
	public  $table = "convertions";
}
