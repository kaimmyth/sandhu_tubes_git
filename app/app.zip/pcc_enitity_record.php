<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pcc_enitity_record extends Model
{
    public $timestamps = false;
	public  $table = "pcc_enitity_record";
}
