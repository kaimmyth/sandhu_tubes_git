<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class manufacturing_details extends Model
{
    public $timestamps = false;
	public  $table = "manufacturing_details";
}
