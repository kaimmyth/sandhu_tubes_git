<style>
  hr.new2 {
  border-top: 1px dashed #000;
}

</style>
<div class="content-page">
 <!-- Start content -->
 <div class="content">
  <div class="container-fluid">
    <!-- Page-Title -->
    <div class="row" id="dashboard-row">
      <div class="col-sm-12">
        <h4 class="pull-left page-title" style="color: #000;font-weight:200;"><i class="ion-arrow-right-b"></i> &nbsp;&nbsp;Land Inventory</h4>
        <ol class="breadcrumb pull-right">
          <li><a href="{{ URL::to('home') }}">Home</a></li>
          <li><a href="{{URL::to('home')}}">land</a></li>
          <li class="active">Land Inventory</li>
        </ol>
      </div>
    </div><hr class="new2">

    <div class="row">
      <div class="col-md-12">
        <div class="card card-border card-info">
        <div class="card-header" style="background-image: linear-gradient(#e1f1f9, white);">
          <div class="card-body" style="    margin-top: -16px;">
           @if($user_id!=1)
            @if(@$module_permission['is_add']=='yes')
            <a href="{{url('land/add')}}" ><button  id="addToTable" class="btn btn-purple btn-rounded waves-effect waves-light m-b-5"  data-toggle="modal" style="float:right; margin-top: 19px;"><i class="md md-add-circle-outline"></i> Add</button></a>
           @endif
           @else
           <a href="{{url('land/add')}}" ><button  id="addToTable" class="btn btn-purple btn-rounded waves-effect waves-light m-b-5"  data-toggle="modal" style="float:right; margin-top: 19px;"><i class="md md-add-circle-outline"></i> Add</button></a>
           @endif
          </div>
     
           <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive"
           style="border-collapse: collapse; border-spacing: 0; width: 100%;">
           <thead style="background: #b6e9ff;">
            <tr>
              <th>Plot No</th>
              <th>Plot Name</th>
              <th>Plot Size</th>
              <th>Area</th>
              <th>Sector</th>
              <th>Block</th>
              <th>Address</th>
              <th>Create Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            @foreach($landdata as $key=>$val)
            <tr>
              <td><a href="{{url('land/edit',$val->id)}}">{{$val->plot_no}}</a></td>
              <td>{{$val->land_name}}</td>
              <td>{{$val->plot_size}} {{$val->uom}}</td>
              <td>{{$val->area}}</td>
              <td>{{$val->sector}}</td>
              <td>{{$val->block}}</td>
              <td>{{$val->address1}}</td>
              <td>{{$val->created_at}}</td>
              <td class="actions">
                @if($user_id!=1)
                @if(@$module_permission['is_edit']=='yes')
                <a href="{{url('land/edit',$val->id)}}"  data-toggle="tooltip" data-placement="top" title="" data-original-title="View/Edit"><i class="fa fa-eye"></i></a>                                      
                &nbsp;&nbsp;&nbsp;
                @endif
                @else
                <a href="{{url('land/edit',$val->id)}}"  data-toggle="tooltip" data-placement="top" title="" data-original-title="View/Edit"><i class="fa fa-eye"></i></a>                                      
                @endif
                <!-- <a href="javascript::void(0)" onclick="viewRecords({{$val->id}})" data-toggle="tooltip" data-placement="top" title="" data-original-title="View"><i class="fa fa-eye"></i></a> -->
              <!--   &nbsp;&nbsp;&nbsp;
                <a href="{{url('inventory-action',$val->id)}}" onclick="return confirm('Are you sure you want to delete this item?');" class="on-default remove-row" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="fas fa-trash"></i></a> -->
              </td>            
            </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</div>
</div>
</div>

<script type="text/javascript">
  function viewRecords() {
    alert('helo')
  }
</script>