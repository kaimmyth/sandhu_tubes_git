<!DOCTYPE html>
<html lang="en">

<head>
    <title>jiada</title>
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <!--// Meta tag Keywords -->

    <!-- Recent Trips section css files-->
    <link rel="stylesheet" href="{{url('public/static-pages-assets/css/owl.carousel.css')}}" type="text/css" media="all">
    <link href="{{url('public/static-pages-assets/css/owl.theme.css')}}" rel="stylesheet">
    <!-- //Recent Trips section css files -->

    <!-- Testimonials -->
    <link rel="stylesheet" href="{{url('public/static-pages-assets/css/flexslider.css')}}" type="text/css" media="screen" />
    <!-- //Testimonials -->

    <!-- css files -->
    <link rel="stylesheet" href="{{url('public/static-pages-assets/css/bootstrap.css')}}">
    <!-- Bootstrap-Core-CSS -->
    <link rel="stylesheet" href="{{url('public/static-pages-assets/css/style.css')}}" type="text/css" media="all" />
    <!-- Style-CSS -->
    <link rel="stylesheet" href="{{url('public/static-pages-assets/css/font-awesome.css')}}">
    <!-- Font-Awesome-Icons-CSS -->
    <!-- //css files -->

    <!-- web-fonts -->
    <link href="https://fonts.googleapis.com/css?family=Gabriela&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Overlock&display=swap" rel="stylesheet">

    <!-- //web-fonts -->

</head>

<body>

    @include("static-pages.header")

    
		<!--start of Ticket -->
	<section class="ticket" style="background: #ffffff; padding: 3em;">
		<div class="container-fluid">
			<div class="col-md-6">
		
			<div class="form_w3layouts">
				 <h3 class="heading" style="color: #000;
				 font-size: 30px;
				 margin-bottom: 19px;">Create Your Ticket</h3>
				<form action="#" method="post" class="agile_form">
					<div class="agileits-location agileinfo-bottom wthree-rating">
						<label>Name</label>
						<input type="text" class="form-control" name="" id="" required=""/>
					</div>
					
					<div class="agileits-location agileinfo-bottom wthree-budget">
						<label>Email</label>
						<input type="text" class="form-control" name="" id="" required=""/>
					</div><br><br>
					
					<div class="agileits-location agileinfo-bottom wthree-rating">
						<label>Phone</label>
						<input type="text" class="form-control" name="" id="" required=""/>
					</div>
					
					<div class="agileits-location agileinfo-bottom wthree-budget">
						<label>Department/Category</label>
						<input type="text" class="form-control" name="" id="" required=""/>
					</div>	

					<div class="agileits-location agileinfo-bottom wthree-rating">
						<label>Priority</label>
						<input type="text" class="form-control" name="" id="" required=""/>
					</div>
					
					<div class="agileits-location agileinfo-bottom wthree-budget">
						<label>Request Type</label>
						<input type="text" class="form-control" name="" id="" required=""/>
					</div>	

					<div class="agileits-location agileinfo-bottom wthree-rating">
						<label>File No.</label>
						<input type="text" class="form-control" name="" id="" required=""/>
					</div>
					
					<div class="agileits-location agileinfo-bottom wthree-budget">
						<label>Choose File</label>
						<input type="text" class="form-control" name="" id="" required=""/>
					</div>
					<div class="agileits-location">
						<label style="    margin-top: 1em;">Description</label>
						<input type="text" class="form-control" name="" id="" required=""/>
					</div>	
					<div class="clear"></div>
					<div class="submit">
						<input type="submit" value="Create Ticket">
					</div>
					
				</form>
			</div>			
		
		
		</div>
		<div class="col-md-6"><br><br>
			<img src="{{url('public/static-pages-assets/images/banner.png')}}" class="img-responsive" alt="Responsive image" width="600" height="440" />
		</div>
		</div>
	</section> 
    <!--end  of Ticket -->
    


    
    <!-- footer start here -->
    <section class="footer-agile">
        <div class="container">
            <div class="footer-btm-agileinfo">
                <div class="col-md-6 col-xs-12 footer-grid w3social">
                    <h3>About us</h3>
                    <p class="footer-p1">JIADA, is responsible for the development of industrial areas in the State of Jharkhand. The administrative set up consists of a Head Office located at Ranchi and is supported by regional offices at Adityapur, Bokaro, Ranchi and Dumka. JIADA is responsible for acquisition of land, development of infrastructure facilities like road, drainage, water supply, public utilities, etc.</p>

                </div>
                <div class="col-md-3 col-xs-12 footer-grid">
                    <h3>Contact Info</h3>
                    <ul>
                        <li><i class="fa fa-phone"></i>+14 999 888 7773</li>
                        <li><i class="fa fa-fax"></i>+12 222 333 2365</li>
                        <li><i class="fa fa-map-marker"></i>Kmome St, NY 10002, Canada.</li>
                        <li><i class="fa fa-envelope-o"></i><a href="mailto:example@mail.com">mail@example.com</a></li>
                        <li><i class="fa fa-globe"></i><a href="#">website@example.com</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-xs-12 footer-grid w3social">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="">Home</a></li>
                        <li><a href="" class="scroll">About</a></li>
                        <li><a href="" class="scroll">Resource</a></li>
                        <li><a href="" class="scroll">Career</a></li>
                        <li><a href="" class="scroll">Contact Us</a></li>
                    </ul>
                </div>

                <div class="clearfix"> </div>
            </div>
            <div class="footer-agilem">
                <div class="col-sm-8 col-xs-9 copy-w3lsright">
                    <p>JAIDA © 2019 IT-SCIENT </a>
                    </p>
                </div>
                <div class="col-sm-4 col-xs-6 social-w3licon">
                    <a href="#" class="social-button twitter"><i class="fa fa-twitter"></i></a>
                    <a href="#" class="social-button facebook"><i class="fa fa-facebook"></i></a>
                    <a href="#" class="social-button google"><i class="fa fa-google-plus"></i></a>
                    <a href="#" class="social-button dribbble"><i class="fa fa-dribbble"></i></a>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>
    <!-- //footer end here -->

    <!-- js-scripts -->

    <!-- js -->
    <script type="text/javascript" src="{{url('public/static-pages-assets/js/jquery-2.1.4.min.js')}}"></script>
    <script type="text/javascript" src="{{url('public/static-pages-assets/js/bootstrap.js')}}"></script>
    <!-- Necessary-JavaScript-File-For-Bootstrap -->
    <!-- //js -->

    <!--  Testimonials js-->
    <script defer src="{{url('public/static-pages-assets/js/jquery.flexslider.js')}}"></script>
    <!--Start-slider-script-->
    <script type="text/javascript">
        $(window).load(function() {
            $('.flexslider').flexslider({
                animation: "slide",
                start: function(slider) {
                    $('body').removeClass('loading');
                }
            });
        });
    </script>
	<!--End-slider-script-->
	

	<script src="{{url('public/static-pages-assets/js/easyResponsiveTabs.js')}}" type="text/javascript"></script>
	<script type="text/javascript">
		$(document).ready(function () {
			$('#horizontalTab').easyResponsiveTabs({
				type: 'default', //Types: default, vertical, accordion           
				width: 'auto', //auto or any width like 600px
				fit: true   // 100% fit in a container
			});
		});
	</script>



	<!--  //Testimonials js-->
	
	<script>
		function openCity(evt, cityName) {
		  var i, tabcontent, tablinks;
		  tabcontent = document.getElementsByClassName("tabcontent");
		  for (i = 0; i < tabcontent.length; i++) {
			tabcontent[i].style.display = "none";
		  }
		  tablinks = document.getElementsByClassName("tablinks");
		  for (i = 0; i < tablinks.length; i++) {
			tablinks[i].className = tablinks[i].className.replace(" active", "");
		  }
		  document.getElementById(cityName).style.display = "block";
		  evt.currentTarget.className += " active";
		}
		
		// Get the element with id="defaultOpen" and click on it
		document.getElementById("defaultOpen").click();
		</script>

    <!-- Recent Trips js file-->
    <script src="{{url('public/static-pages-assets/js/owl.carousel.js')}}"></script>
    <!-- Recent Trips Script-->
    <script>
        $(document).ready(function() {
            $("#owl-demo").owlCarousel({

                autoPlay: 3000, //Set AutoPlay to 3 seconds
                autoPlay: true,
                items: 3,
                itemsDesktop: [640, 5],
                itemsDesktopSmall: [414, 4]

            });

        });
    </script>
    <!-- //Recent Trips section Script-->
    <!-- //Recent Trips js file-->

    <!-- start-smoth-scrolling -->
    <script src="{{url('public/static-pages-assets/js/SmoothScroll.min.js')}}"></script>
    <script type="text/javascript" src="{{url('public/static-pages-assets/js/move-top.js')}}"></script>
    <script type="text/javascript" src="{{url('public/static-pages-assets/js/easing.js')}}"></script>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".scroll").click(function(event) {
                event.preventDefault();
                $('html,body').animate({
                    scrollTop: $(this.hash).offset().top
                }, 1000);
            });
        });
    </script>
    <!-- here stars scrolling icon -->
    <script type="text/javascript">
        $(document).ready(function() {
            /*
            	var defaults = {
            	containerID: 'toTop', // fading element id
            	containerHoverID: 'toTopHover', // fading element hover id
            	scrollSpeed: 1200,
            	easingType: 'linear' 
            	};
            */

            $().UItoTop({
                easingType: 'easeOutQuart'
            });

        });
    </script>
    <!-- //here ends scrolling icon -->
    <!-- start-smoth-scrolling -->

    <!-- Banner-js -->
    <script src="{{url('public/static-pages-assets/js/responsiveslides.min.js')}}"></script>
    <script>
        $(function() {
            $("#slider").responsiveSlides({
                auto: true,
                pager: false,
                nav: true,
                speed: 1000,
                namespace: "callbacks",
                before: function() {
                    $('.events').append("<li>before event fired.</li>");
                },
                after: function() {
                    $('.events').append("<li>after event fired.</li>");
                }
            });
        });
    </script>
    <!-- //Baneer-js -->

    <!-- script for fonts --
		<script>
		$(document).ready(function() {

		var fontSize = $(window).width()/50;
		$('body').css('font-size', fontSize);

		$(window).resize(function() {
		var fontSize = $(window).width()/50;
		$('body').css('font-size', fontSize);
		});

		});
		</script>
	<!-- //script for fonts -->

    <!-- //js-scripts -->
</body>

</html>