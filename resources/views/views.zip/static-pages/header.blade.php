<!-- Header -->



<div class="header ">
    <nav class="navbar navbar-default ">

        <!--  -->
        <!-- navbar-header -->
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
               <!-- <h1><a href="{{url('/')}}"><i class="md md-terrain"></i>Sandhu Tubes</a></h1>-->
				
				<h1><a href="#"><img src="public/images/logo1.png" style="border: none;"></a></h1>
				
            </div>
            <!-- <div class="top-nav-text">
                <div class="search-w3layouts">
                    <form action="#" method="post" class="search-bottom-wthree d-flex my-md-0 my-2">
                        <input class="search col" type="search" placeholder="Search Here..." required="">
                    </form>
                </div>
            </div> -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav" style="    margin-top: 2em;">
                    <!--<li><a class="hvr-underline-from-center active" href="{{url('homepage')}}">Home</a></li>-->
                    <li><a href="#" data-toggle="dropdown"><span data-hover="dropdown">About Us</span><span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <!--<li><a href="#mission" class="scroll"><span data-hover="">About</span></a></li>-->
                            <!-- <li><a href="#management-team" class="scroll"><span data-hover="">Management Team</span></a></li> -->
                            
                        </ul>
                    </li> 
                    <li><a href="#" data-toggle="dropdown"><span data-hover="dropdown">Products</span><span class="caret"></span></a>
                        <ul class="dropdown-menu">
                         
                            <!-- <li><a href="#packages" class="scroll"><span data-hover="">Important Links</span></a></li>
                            <li><a href="#" class="scroll"><span data-hover="">Tender</span></a></li> -->
                            
                        </ul>
                    </li>
					<!-- <li><a href="{{url('unit')}}" class="hvr-underline-from-center ">Serivces</a></li> -->
                    <li><a href="#" class="hvr-underline-from-center">Career</a></li>
                    <li><a href="#contact" class="scroll">Contact</a>
					<li><a href="{{url('portal')}}" class="hvr-underline-from-center ">Login</a></li>



                </ul>
            </div>
        </div>

        <div class="clearfix"> </div>
    </nav>
</div>




<!-- //Header -->